<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return 'Página inicial';
})->name('home');

Route::get('/user/{id}', function ($id) {
    return "Perfil do usuário com ID {$id}";
})->name('user.profile');

Route::get('/post/{slug}', function ($slug) {
    return "Post do blog com slug {$slug}";
})->name('blog.post');

Route::get('/category/{category}', function ($category) {
    return "Listando posts da categoria: {$category}";
})->name('blog.category');

Route::get('/user/{id}/language/{lang?}', function ($id, $lang = null) {
    if ($lang) {
        return "Perfil do usuário {$id} na língua {$lang}";
    } else {
        return "Perfil do usuário {$id}";
    }
})->name('user.profile.language');

Route::get('/products/{category}/{minPrice?}', function ($category, $minPrice = null) {
    if ($minPrice) {
        return "Listando produtos da categoria {$category} com preço mínimo de {$minPrice}";
    } else {
        return "Listando produtos da categoria {$category}";
    }
})->name('products.category.price');

Route::get('/page/{page}', function ($page) {
    return "Página número {$page}";
})->name('page.number')->where('page', '[0-9]+');

Route::get('/convert/{money}', function ($money) {
    return "Convertendo {$money} reais para dólar";
})->name('currency.converter')->where('money', '[0-9]+(\.[0-9]{1,2})?');

Route::get('/sum/{number1}/{number2}', function ($number1, $number2) {
    $sum = $number1 + $number2;
    return "A soma de {$number1} e {$number2} é {$sum}";
})->name('sum.numbers')->where(['number1' => '[0-9]+', 'number2' => '[0-9]+']);

